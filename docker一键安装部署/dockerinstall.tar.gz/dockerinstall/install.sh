#!/bin/bash  
  
# 定义要安装的 DEB 包  
CONTAINERD_DEB="containerd.io_1.6.22-1_amd64.deb"  
DOCKER_CLI_DEB="docker-ce-cli_24.0.5-1~ubuntu.22.04~jammy_amd64.deb"  
DOCKER_DEB="docker-ce_24.0.5-1~ubuntu.22.04~jammy_amd64.deb"  
  
# 检查文件是否存在  
for deb_file in "$CONTAINERD_DEB" "$DOCKER_CLI_DEB" "$DOCKER_DEB"; do  
    if [ ! -f "$deb_file" ]; then  
        echo "Error: File $deb_file does not exist."  
        exit 1  
    fi  
done  
  
# 安装 DEB 包  
for deb_file in "$CONTAINERD_DEB" "$DOCKER_CLI_DEB" "$DOCKER_DEB"; do  
    echo "Installing $deb_file..."  
    sudo dpkg -i "$deb_file"  
    if [ $? -ne 0 ]; then  
        echo "Failed to install $deb_file. Please check dependencies and try again."  
        exit 1  
    fi  
done  
  
# 确保 Docker 服务启用并尝试启动  
echo "Enabling and starting Docker service..."  
sudo systemctl enable docker  
if [ $? -ne 0 ]; then  
    echo "Failed to enable Docker service."  
    exit 1  
fi  
sudo systemctl start docker  
if [ $? -ne 0 ]; then  
    echo "Failed to start Docker service."  
    exit 1  
fi  
  
# 检查 Docker 服务状态  
echo "Checking Docker service status..."  
if ! sudo systemctl status docker | grep -q 'active (running)'; then  
    echo "Docker service is not running."  
    exit 1  
fi  
  
# 复制 docker-compose 到 /usr/local/bin 并设置权限  
if [ ! -f /usr/local/bin/docker-compose ]; then  
    echo "Copying docker-compose to /usr/local/bin..."  
    sudo cp docker-compose /usr/local/bin/docker-compose  
    if [ $? -ne 0 ]; then  
        echo "Failed to copy docker-compose."  
        exit 1  
    fi  
    sudo chmod +x /usr/local/bin/docker-compose  
    if [ $? -ne 0 ]; then  
        echo "Failed to set executable permission for docker-compose."  
        exit 1  
    fi  
else  
    echo "docker-compose already exists in /usr/local/bin."  
fi  
  
echo "Good Job! Docker and docker-compose Installation and setup completed successfully."
