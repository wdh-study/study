#!/bin/bash  
  
# 停止 Docker 服务  
echo "Stopping Docker service..."  
sudo systemctl stop docker  
if [ $? -ne 0 ]; then  
    echo "Failed to stop Docker service."  
    exit 1  
fi  
  
# 卸载 Docker-CE, Docker-CE-CLI 和 Containerd.io  
echo "Purging Docker packages..."  
sudo apt-get purge -y docker-ce docker-ce-cli containerd.io  
if [ $? -ne 0 ]; then  
    echo "Failed to purge Docker packages."  
    exit 1  
fi  
  
# 移除 Docker 的配置文件和数据  
echo "Removing Docker configuration files and data..."  
sudo rm -rf /var/lib/docker  
sudo rm -rf /etc/docker  
  
# 注意：通常不建议直接删除 /var/run/docker.sock，因为它是由 systemd 管理的，  
# 并且在 Docker 服务重启或系统重启时可能会重新创建。  
# 但如果您确实想确保它被删除（例如在彻底清理环境中），可以这样做：  
# sudo rm /var/run/docker.sock  
# 这里我们选择不直接删除它，而是让 systemd 管理它。  
  
# 移除 docker-compose（如果之前是通过 cp 命令复制到 /usr/local/bin 的）  
if [ -f /usr/local/bin/docker-compose ]; then  
    echo "Removing docker-compose from /usr/local/bin..."  
    sudo rm /usr/local/bin/docker-compose  
fi  
  
# 清理 apt 缓存（可选，但推荐）  
echo "Cleaning apt cache..."  
sudo apt-get autoremove -y  
sudo apt-get autoclean -y  

echo "Good Job! Docker and docker-compose have been uninstalled successfully."
